﻿// Abstractactor.SetOccupiedDesignMask - всегда пропускать opuDesignMask устанавливать в null
// GetSelfTerrainModifier - всегда возвращать 0, на постфиксе GetAllModifiers и GetAllModifiersDescription вызывать специальную версию учитывающую личность атакующего
// GetTargetTerrainModifier - цель передается