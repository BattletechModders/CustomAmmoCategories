using System;
using System.IO;
using System.Text;

using HybridDSP.Net.HTTP;

namespace CommandLineServer
{
    class DateTimeHandler : IHTTPRequestHandler
    {
        public void HandleRequest(HTTPServerRequest request, HTTPServerResponse response)
        {
            if (request.URI == "/")
            {
                /**
                 * In this example we'll write the body into the
                 * stream obtained by response.Send(). This will cause the
                 * KeepAlive to be false since the size of the body is not
                 * known when the response header is sent.
                 **/
                response.ContentType = "text/html";
                using (Stream ostr = response.Send())
                using (TextWriter tw = new StreamWriter(ostr))
                {
                    tw.WriteLine("<html>");
                    tw.WriteLine("<head>");
                    tw.WriteLine("<title>Date Time Server</title>");
                    tw.WriteLine("<meta http-equiv=\"refresh\" content=\"2\">");
                    tw.WriteLine("</header>");
                    tw.WriteLine("<body>");
                    tw.WriteLine(DateTime.Now.ToString());
                    tw.WriteLine("</body>");
                    tw.WriteLine("</html>");
                }
            }
            else
            {
                response.StatusAndReason = HTTPServerResponse.HTTPStatus.HTTP_NOT_FOUND;
                response.Send();
            }
        }
    }

    class RequestHandlerFactory : IHTTPRequestHandlerFactory
    {
        public IHTTPRequestHandler CreateRequestHandler(HTTPServerRequest request)
        {
            return new DateTimeHandler();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            RequestHandlerFactory factory = new RequestHandlerFactory();
            HTTPServer server = new HTTPServer(factory, 8080);
            server.Start();

            Console.Write("Press enter to abort.");
            Console.ReadKey();

            server.Stop();
        }
    }
}
